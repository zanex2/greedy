Copy the RSMB6AE folder into the following folder:
C:\Program Files\Adobe\Common\Plug-ins\7.0\MediaCore

SN: not required

